package com.codingdojo.petzlove.models;

import java.util.Base64;

public class ImageUtil {
    public static String convertImageToBase64(byte[] imageData) {
        if (imageData != null && imageData.length > 0) {
            return Base64.getEncoder().encodeToString(imageData);
        } else {
            // Return a default image URL or base64-encoded placeholder image data
            return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8HwV9DwAJhAHKcIjAAAAABJRU5ErkJggg==";
        }
    }
}
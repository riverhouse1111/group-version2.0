package com.codingdojo.petzlove.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.codingdojo.petzlove.models.Product;
import com.codingdojo.petzlove.models.User;

@Repository
public interface ProductRepository extends CrudRepository<Product, Long> {
	List<Product> findAll();
	List<Product> findAllByUser(User user);
}
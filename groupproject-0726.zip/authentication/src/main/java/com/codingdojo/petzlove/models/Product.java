package com.codingdojo.petzlove.models;

import java.util.Base64;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="products")



public class Product {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private Long id;
		
		@NotEmpty(message="Product name is required!")
		@Size(min=3, max=30, message="Product name must be between 3 and 30 characters.")
		private String pName;
		
		@NotEmpty(message="Product description is required!")
		@Size(min=3, max=255, message="Product description must be between 3 and 255 characters.")
		private String pDesc;
		
		@NotNull(message="Invalid price!")
		@Min(value=0, message="Price must be above $0.")
		private Long pPrice;
		
		@NotNull(message="Invalid stock!")
		@Min(value=0, message="Stock can not be negative.")
		private Long pStock;
		
		@NotNull(message="No assigned pet ID!")
		private Long pPetID;
		
		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name="user_id")
		private User user;
		
	    @Lob
	    @Column(name = "image_data", columnDefinition = "BLOB")
	    private byte[] imageData;
	    
		public Product() { }
		
		public Product(Long id, String name, String desc, Long price, Long stock, Long petid, User user){
			this.id = id;
			this.pName = name;
			this.pDesc = desc;
			this.pPrice = price;
			this.pStock = stock;
			this.pPetID = petid;
			this.user = user;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getpName() {
			return pName;
		}

		public void setpName(String pName) {
			this.pName = pName;
		}

		public String getpDesc() {
			return pDesc;
		}

		public void setpDesc(String pDesc) {
			this.pDesc = pDesc;
		}

		public Long getpPrice() {
			return pPrice;
		}

		public void setpPrice(Long pPrice) {
			this.pPrice = pPrice;
		}

		public Long getpStock() {
			return pStock;
		}

		public void setpStock(Long pStock) {
			this.pStock = pStock;
		}

		public Long getpPetID() {
			return pPetID;
		}

		public void setpPetID(Long pPetID) {
			this.pPetID = pPetID;
		}

		public User getUser() {
			return user;
		}

		public void setUser(User user) {
			this.user = user;
		}

		public byte[] getImageData() {
			return imageData;
		}

		public void setImageData(byte[] imageData) {
			this.imageData = imageData;
		}

		public void setImage(byte[] imageData2) {
			// TODO Auto-generated method stub
			
		}

	

		
}

